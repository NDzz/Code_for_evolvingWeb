var canvas;
var ctx;
var w = window.innerWidth;
var h = 700;
var allData = [];
var mouse = {"x": 0, "y":0};

////////////////////////////////////////////////////
setUpCanvas();

canvas.onmousemove = function(){
// console.log(event.clientX, event.clientY);
	mouse.x = event.clientX;
	mouse.y = event.clientY;
}



createData(900);
animationLoop();

////////////////////////////////////////////////////
function animationLoop(){
	///code to loop over
	clear();
	AllData();
	requestAnimationFrame(animationLoop);

}
function AllData(){
	for(var i = 0; i < allData.length;i++){
		
		Square(allData[i]);
		move(allData[i]);
		bound(allData[i]);
			
		}
	}	

function bound(o){/////rebound function
	if(o.x + (o.r) > w||o.x < 0){
		o.dx *= -1
	};
	if(o.y + o.r > h||o.y < 0){
		o.dy *= -1
	};
}


function move(o){
	o.x += o.dx;
	o.y += o.dy

//mouse's radius to colour in the squares
	if (mouse.x - (o.x+o.r) < 80 && mouse.x -(o.x+o.r) > -80
		&& mouse.y - (o.y+o.r)-150 < 80 && mouse.y - (o.y+o.r)-150 > -80)
	{ctx.fill();}

}

function createData(num){
	for(var i = 0; i<num; i++){
		allData.push({
			"x":  rand(w-100)+ 25,
			"y":  rand(h-100)+ 25,
			"dx": (Math.random(rand())- .5)*(document.onkeydown = function createData(){
						if(event.which == 38){speed(1)}}),
			"dy": (Math.random(rand())- .5)*1,
			"r":  rand(50) + 10,
			"c":  rand(360),
			"a":  rand(1),
		})
	}
}
function speed(){
	1
}

function Square(o){
	ctx.beginPath();
	ctx.rect(o.x, o.y, o.r, o.r)
	ctx.strokeStyle = "hsla("+o.c+", 0%, 0%,"+o.a+")";
	ctx.lineWidth   = "2"
	ctx.fillStyle   = "hsla("+o.c+", 100%, 50%,"+o.a+")";
	ctx.stroke();
}

function randi(num){
	var result = Math.floor(Math.random()* num)
	 return result 
}
function rand(num){
	 var result = Math.random()* num;
	 return result 
}
///claer
function clear(){
ctx.clearRect(0,0,w,h);
}
///// setup canvas 
function setUpCanvas (){
	canvas = document.querySelector("#canvas");
	canvas.width = w; 
	canvas.height = h;
	ctx = canvas. getContext("2d");
}
